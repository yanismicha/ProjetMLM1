#' scinde une data
#' fonction permettant de recuperer une subdata avec seulement le type de variables specifie
#'
#' @param data un dataframe
#' @param type une chaine de caractere specifiant la partie retourne
#'
#' @return
#' @export
#'
#' @examples
scinde <- function(data, type) {
  names_data_quanti <- c()
  names_data_quali <- c()
  names_data_binaire <- c()
  names_data<-names(data)
  for(i in 1:length(names_data)){
    var <- names_data[i]
    if(is.numeric(data[,var])){
      names_data_quanti <- append(names_data_quanti,var)
    }
    else {
      names_data_quali <- append(names_data_quali,var)
      if(length(levels(as.factor(data[,var])))== 2){
        names_data_binaire <- append(names_data_binaire,var)
      }
    }
  }
  if(type == "quanti")
      names_data_quanti
    #data[,names_data_quanti]
  else if (type == "quali")
      names_data_quali
  else if (type == "binaire")
      names_data_binaire
  else
    print('le type doit etre:"quanti","quali" ou "binaire')
}
